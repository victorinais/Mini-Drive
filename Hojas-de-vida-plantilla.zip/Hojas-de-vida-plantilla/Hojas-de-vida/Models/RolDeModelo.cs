namespace GHV.Models
{
    public class RolDeModelo
    {
        public int RolId { get; set; }
        public string? TipoDeModulo { get; set; }
        public int ModeloId { get; set; }
    }
}