
using Microsoft.AspNetCore.Mvc;


namespace GHV.Controllers.User
{
    public class UserController : Controller
    {

        public IActionResult Usuario(string nombreUsuario)
        {
            ViewData["NombreUsuario"] = nombreUsuario;
            return View();
        }
    }
}