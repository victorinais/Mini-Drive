
using GHV.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace GHV.Controllers
{
    public class CvController : Controller
    {  
        public IActionResult InformacionAcademica()
        {
            return View();
        }
        public IActionResult InformacionLaboral()
        {
            return View();
        }
        public IActionResult Habilidades()
        {
            return View();
        }
        public IActionResult InformacionPersonal()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GuardarInformacionPersonal(InformacionPersonalViewModel model)
        {
            // Validar los datos del modelo
            if (!ModelState.IsValid)
            {
                return View("InformacionPersonal", model);
            }

            // Lógica de guardado (ejemplo: guardar en base de datos)
            // ...

            return RedirectToAction("InformacionAcademica"); // O cualquier otra acción de redirección
        }
    }
}