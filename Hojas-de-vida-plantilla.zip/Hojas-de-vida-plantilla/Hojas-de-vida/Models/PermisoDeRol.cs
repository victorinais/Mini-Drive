namespace GHV.Models
{
    public class PermisoDeRol
    {
        public int RolId { get; set; }
        public int PermisoId { get; set; }
    }
}