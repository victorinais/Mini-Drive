
using Microsoft.AspNetCore.Mvc;

namespace GHV.Admin
{
    public class AdminController : Controller
    {

        public IActionResult Admin(string nombreUsuario)
        {
            ViewData["NombreUsuario"] = nombreUsuario;
            return View();
        }
    }
}