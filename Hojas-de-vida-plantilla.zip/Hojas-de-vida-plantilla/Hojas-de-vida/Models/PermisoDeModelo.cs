namespace GHV.Models
{
    public class PermisoDeModelo
    {
        public int PermisoId { get; set; }
        public string? TipoDeModelo { get; set; }
        public int ModeloId { get; set; }
    }
}