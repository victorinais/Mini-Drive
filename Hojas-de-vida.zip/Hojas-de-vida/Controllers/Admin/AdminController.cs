
using Microsoft.AspNetCore.Mvc;
using GHV.Data;


namespace GHV.Controllers
{
    [Route("[controller]")]
    public class AdminController : Controller
    {
        private readonly BaseContext _context;
        public AdminController(BaseContext context)
        {
            _context = context;
        }
        /*administrador*/
        public IActionResult Administrador()
        {

            return View();  
        }
    }
}