using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GHV.Models
{
    public class ModelosDePermiso
    {
        public int PermisoId { get; set; }
        public string TipoDeModelo { get; set; }
        public int ModeloId { get; set; }
    }
}