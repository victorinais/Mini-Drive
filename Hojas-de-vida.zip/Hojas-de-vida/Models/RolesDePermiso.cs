using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GHV.Models
{
     public class RolesDePermiso
    {
        public int RolId { get; set; }
        public int PermisoId { get; set; }
    }
}