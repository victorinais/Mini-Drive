using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GHV.Models
{
    public class RolesDeModelo
    {
        public int RolId { get; set; }
        public string TipoDeModulo { get; set; }
        public int ModeloId { get; set; }
    }
}